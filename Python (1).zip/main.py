import random
#imports library "random" to choose words
print("Welcome to Hangman")
#prints the welcome message
def hangman():
  #defines the function "hangman"
    images = [
      #defines the variable "images" as a list of images to be used in the game
        """
           __
          |  |
             |
             |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
             |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
          |  |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|  |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|\\ |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|\\ |
         /   |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|\\ |
         / \\ |
             |
        =========
        """
    ]

    words = ["america", "movie", "computers", "science", "supercalifragilisticexpialidocious"]
  #defines the variable "words" as a list of string variables to be  used in the game
    chosen_word = random.choice(words)
  #defines the variable "chosen_word" as a random word from the list "words"
    guess_word = ["_" for _ in range(len(chosen_word))]
  #sets up the game by defining the variable "guess_word" as a list of underscores the same length as the chosen word
    attempts = 6
  #sets the number of attempts the player has to guess the word

    while attempts > 0:
      #while loop that runs until the player runs out of attempts
        print("\n" + " ".join(guess_word))
        guess = input("Enter a letter: ")
      #define variable guess as an input from the user
        if guess in chosen_word:
          #if statement that runs if the guess is in the chosen word
            for i in range(len(chosen_word)):
                if chosen_word[i] == guess:
                    guess_word[i] = guess
                  #replaces the underscore with the guessed letter in the guess word
            if "_" not in guess_word:
              #if statement that runs if the player has guessed all the letters in the chosen word
                print("Good Job! You saved his life. The word was:", chosen_word)
                break
        else:
            attempts -= 1
          #takes away attempts for incorrect guesses
            print(images[6 - attempts])
            print(f"Incorrect! You have {attempts} attempts left.")

    if attempts == 0:
      #says what to do if the player loses
        print("Oops! You hung him out to die. The word was:", chosen_word)

hangman() #plays the game