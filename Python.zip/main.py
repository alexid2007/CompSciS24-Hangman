import random
print("Welcome to Hangman")
def hangman():
    images = [
        """
           __
          |  |
             |
             |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
             |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
          |  |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|  |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|\\ |
             |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|\\ |
         /   |
             |
        =========
        """,
        """
           __
          |  |
          O  |
         /|\\ |
         / \\ |
             |
        =========
        """
    ]

    words = ["america", "movie", "computers", "science", "supercalifragilisticexpialidocious"]
    chosen_word = random.choice(words)
    guess_word = ["_" for _ in range(len(chosen_word))]
    attempts = 6

    while attempts > 0:
        print("\n" + " ".join(guess_word))
        guess = input("Enter a letter: ")
        if guess in chosen_word:
            for i in range(len(chosen_word)):
                if chosen_word[i] == guess:
                    guess_word[i] = guess
            if "_" not in guess_word:
                print("Good Job! You saved his life. The word was:", chosen_word)
                break
        else:
            attempts -= 1
            print(images[6 - attempts])
            print(f"Incorrect! You have {attempts} attempts left.")

    if attempts == 0:
        print("Oops! You hung him out to die. The word was:", chosen_word)

hangman()